var direc = 'https://api.pamplin.vt.edu/v1/persons/directory?kind=pamplin'
var direc = 'direct.json'
var json = direc;

$.getJSON(direc, function(data) {
    $.each(data, function(d, i) {
        $('#name').html(i.department);
        $('#period').html(i.displayName);
        $('#location').html(i.telephoneNumber);
        $('#discovered').html(i.title);

        var name_card = document.createElement('li');
        var displayName = document.createElement('displayName');
        var title = document.createElement('title');
        var email = document.createElement('email');
        var telephoneNumber = document.createElement('telephoneNumber');
        var postalAddress = document.createElement('postalAddress');

        displayName.innerHTML = i.displayName;
        title.innerHTML = i.title;
        email.innerHTML = i.email;
        telephoneNumber.innerHTML = i.telephoneNumber;
        postalAddress.innerHTML = i.postalAddress.replace(/\$/g, '_');

        name_card.appendChild(displayName);
        name_card.appendChild(title);
        name_card.appendChild(email);
		name_card.appendChild(telephoneNumber);
		name_card.appendChild(postalAddress);

        document.body.appendChild(name_card);
        // // Set its contents:
        // item.appendChild(document.createTextNode(i.department));

        // console.log(i);

        // // Add it to the list:
        // $('#what').appendChild(item);

        // console.log(i);
    });
});